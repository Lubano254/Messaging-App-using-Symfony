<?php

/**
 * This file has been auto-generated
 * by the Symfony Routing Component.
 */

return [
    false, // $matchHost
    [ // $staticRoutes
        '/' => [[['_route' => 'message', '_controller' => 'App\\Controller\\MessageController::index'], null, null, null, false, false, null]],
    ],
    [ // $regexpList
        0 => '{^(?'
                .'|/message/([^/]++)(?'
                    .'|(*:27)'
                    .'|/delete(*:41)'
                .')'
            .')/?$}sDu',
    ],
    [ // $dynamicRoutes
        27 => [[['_route' => 'message_details', '_controller' => 'App\\Controller\\MessageController::details'], ['id'], null, null, false, true, null]],
        41 => [
            [['_route' => 'delete_message', '_controller' => 'App\\Controller\\MessageController::delete'], ['id'], null, null, false, false, null],
            [null, null, null, null, false, false, 0],
        ],
    ],
    null, // $checkCondition
];
